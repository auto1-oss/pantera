<?php
namespace Ayd\Helper;

class Helper {
    public static function greet(string $name): string {
        return "Hello, $name!";
    }
}
