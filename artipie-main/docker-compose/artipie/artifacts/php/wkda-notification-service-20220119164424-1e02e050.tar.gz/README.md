## Contribution
This repository is READ-ONLY. Please be aware: ANY changes committed/merged will be thrown away with `sudo --force`.

Please proceed with PR to the mono-repo here: [wkda/php-dto-collection](https://github.com/wkda/php-dto-collection)
