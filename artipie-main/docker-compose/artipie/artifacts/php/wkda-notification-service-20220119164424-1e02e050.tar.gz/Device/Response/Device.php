<?php

declare(strict_types=1);

namespace WKDA\DTO\NotificationService\Device\Response;

/**
 * Class Device
 */
class Device
{
    /**
     * @var string|null
     */
    private $clientDeviceId;

    /**
     * @var string|null
     */
    private $deviceToken;

    /**
     * @var string|null
     */
    private $deviceType;

    /**
     * @var int|null
     */
    private $discr;

    /**
     * @var string|null
     */
    private $endpointArn;

    /**
     * @var string|null
     */
    private $id;

    /**
     * @var string|null
     */
    private $merchantUserUuid;

    /**
     * @var string|null
     */
    private $mobileAppVersion;

    /**
     * @var string|null
     */
    private $registeredOn;

    /**
     * @var string|null
     */
    private $relatedEntityId;

    /**
     * @return string|null
     */
    public function getClientDeviceId(): ?string
    {
        return $this->clientDeviceId;
    }

    /**
     * @param string|null $clientDeviceId
     *
     * @return self
     */
    public function setClientDeviceId(?string $clientDeviceId): self
    {
        $this->clientDeviceId = $clientDeviceId;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getDeviceToken(): ?string
    {
        return $this->deviceToken;
    }

    /**
     * @param string|null $deviceToken
     *
     * @return self
     */
    public function setDeviceToken(?string $deviceToken): self
    {
        $this->deviceToken = $deviceToken;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getDeviceType(): ?string
    {
        return $this->deviceType;
    }

    /**
     * @param string|null $deviceType
     *
     * @return self
     */
    public function setDeviceType(?string $deviceType): self
    {
        $this->deviceType = $deviceType;

        return $this;
    }

    /**
     * @return int|null
     */
    public function getDiscr(): ?int
    {
        return $this->discr;
    }

    /**
     * @param int|null $discr
     *
     * @return self
     */
    public function setDiscr(?int $discr): self
    {
        $this->discr = $discr;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getEndpointArn(): ?string
    {
        return $this->endpointArn;
    }

    /**
     * @param string|null $endpointArn
     *
     * @return self
     */
    public function setEndpointArn(?string $endpointArn): self
    {
        $this->endpointArn = $endpointArn;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getId(): ?string
    {
        return $this->id;
    }

    /**
     * @param string|null $id
     *
     * @return self
     */
    public function setId(?string $id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getMerchantUserUuid(): ?string
    {
        return $this->merchantUserUuid;
    }

    /**
     * @param string|null $merchantUserUuid
     *
     * @return self
     */
    public function setMerchantUserUuid(?string $merchantUserUuid): self
    {
        $this->merchantUserUuid = $merchantUserUuid;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getMobileAppVersion(): ?string
    {
        return $this->mobileAppVersion;
    }

    /**
     * @param string|null $mobileAppVersion
     *
     * @return self
     */
    public function setMobileAppVersion(?string $mobileAppVersion): self
    {
        $this->mobileAppVersion = $mobileAppVersion;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getRegisteredOn(): ?string
    {
        return $this->registeredOn;
    }

    /**
     * @param string|null $registeredOn
     *
     * @return self
     */
    public function setRegisteredOn(?string $registeredOn): self
    {
        $this->registeredOn = $registeredOn;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getRelatedEntityId(): ?string
    {
        return $this->relatedEntityId;
    }

    /**
     * @param string|null $relatedEntityId
     *
     * @return self
     */
    public function setRelatedEntityId(?string $relatedEntityId): self
    {
        $this->relatedEntityId = $relatedEntityId;

        return $this;
    }
}
