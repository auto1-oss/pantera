<?php

declare(strict_types=1);

namespace WKDA\DTO\NotificationService\Device\Enum;

/**
 * Class DeviceType
 */
class DeviceType
{
    public const TYPE_ANDROID   = 'ANDROID';
    public const TYPE_IOS       = 'IOS';
}
