<?php

declare(strict_types=1);

namespace WKDA\DTO\NotificationService\Device\Enum;

/**
 * Class Discr
 */
class Discr
{
    public const ADMIN      = 3;
    public const MERCHANT   = 1;
}
