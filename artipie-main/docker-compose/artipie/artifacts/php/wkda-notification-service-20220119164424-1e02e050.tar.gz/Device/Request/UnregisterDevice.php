<?php

declare(strict_types=1);

namespace WKDA\DTO\NotificationService\Device\Request;

use Auto1\ServiceAPIRequest\ServiceRequestInterface;

/**
 * Class UnregisterDevice
 */
class UnregisterDevice implements ServiceRequestInterface
{
    /**
     * @var string|null
     */
    private $relatedEntityUuid;

    /**
     * @var string|null
     */
    private $clientDeviceId;

    /**
     * @var string|null
     */
    private $application;

    /**
     * @var int|null
     */
    private $discr;

    /**
     * @return string|null
     */
    public function getRelatedEntityUuid(): ?string
    {
        return $this->relatedEntityUuid;
    }

    /**
     * @param string|null $relatedEntityUuid
     *
     * @return $this
     */
    public function setRelatedEntityUuid(?string $relatedEntityUuid): self
    {
        $this->relatedEntityUuid = $relatedEntityUuid;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getClientDeviceId(): ?string
    {
        return $this->clientDeviceId;
    }

    /**
     * @param string|null $clientDeviceId
     *
     * @return $this
     */
    public function setClientDeviceId(?string $clientDeviceId): self
    {
        $this->clientDeviceId = $clientDeviceId;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getApplication(): ?string
    {
        return $this->application;
    }

    /**
     * @param string|null $application
     *
     * @return $this
     */
    public function setApplication(?string $application): self
    {
        $this->application = $application;

        return $this;
    }

    /**
     * @return int|null
     */
    public function getDiscr(): ?int
    {
        return $this->discr;
    }

    /**
     * @param int|null $discr
     *
     * @return $this
     */
    public function setDiscr(?int $discr): self
    {
        $this->discr = $discr;

        return $this;
    }
}
