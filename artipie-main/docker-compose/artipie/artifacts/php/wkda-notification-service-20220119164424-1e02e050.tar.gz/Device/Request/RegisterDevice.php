<?php

declare(strict_types=1);

namespace WKDA\DTO\NotificationService\Device\Request;

use Auto1\ServiceAPIRequest\ServiceRequestInterface;

/**
 * Class RegisterDevice
 */
class RegisterDevice implements ServiceRequestInterface
{
    /**
     * @var string|null
     */
    private $relatedEntityUuid;

    /**
     * @var string|null
     */
    private $clientDeviceId;

    /**
     * @var string|null
     */
    private $deviceToken;

    /**
     * @var string|null
     */
    private $deviceType;

    /**
     * @var int|null
     */
    private $discr;

    /**
     * @var string|null
     */
    private $mobileApp;

    /**
     * @var string|null
     */
    private $mobileAppVersion;

    /**
     * @return string|null
     */
    public function getRelatedEntityUuid(): ?string
    {
        return $this->relatedEntityUuid;
    }

    /**
     * @param string|null $relatedEntityUuid
     *
     * @return $this
     */
    public function setRelatedEntityUuid(?string $relatedEntityUuid): self
    {
        $this->relatedEntityUuid = $relatedEntityUuid;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getClientDeviceId(): ?string
    {
        return $this->clientDeviceId;
    }

    /**
     * @param string|null $clientDeviceId
     *
     * @return $this
     */
    public function setClientDeviceId(?string $clientDeviceId): self
    {
        $this->clientDeviceId = $clientDeviceId;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getDeviceToken(): ?string
    {
        return $this->deviceToken;
    }

    /**
     * @param string|null $deviceToken
     *
     * @return $this
     */
    public function setDeviceToken(?string $deviceToken): self
    {
        $this->deviceToken = $deviceToken;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getDeviceType(): ?string
    {
        return $this->deviceType;
    }

    /**
     * @param string|null $deviceType
     *
     * @return $this
     */
    public function setDeviceType(?string $deviceType): self
    {
        $this->deviceType = $deviceType;

        return $this;
    }

    /**
     * @return int|null
     */
    public function getDiscr(): ?int
    {
        return $this->discr;
    }

    /**
     * @param int|null $discr
     *
     * @return $this
     */
    public function setDiscr(?int $discr): self
    {
        $this->discr = $discr;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getMobileApp(): ?string
    {
        return $this->mobileApp;
    }

    /**
     * @param string|null $mobileApp
     *
     * @return $this
     */
    public function setMobileApp(?string $mobileApp): self
    {
        $this->mobileApp = $mobileApp;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getMobileAppVersion(): ?string
    {
        return $this->mobileAppVersion;
    }

    /**
     * @param string|null $mobileAppVersion
     *
     * @return $this
     */
    public function setMobileAppVersion(?string $mobileAppVersion): self
    {
        $this->mobileAppVersion = $mobileAppVersion;

        return $this;
    }
}
