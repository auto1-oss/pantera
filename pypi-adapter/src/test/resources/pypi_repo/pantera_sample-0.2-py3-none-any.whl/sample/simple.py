def hello():
    return "Hello from pantera-sample"
