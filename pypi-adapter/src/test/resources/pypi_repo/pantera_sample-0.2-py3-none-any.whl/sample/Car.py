class Car:
    """A simple car class for testing."""
    def __init__(self, make="Pantera", model="GTS"):
        self.make = make
        self.model = model
    def __str__(self):
        return f"{self.make} {self.model}"
