from setuptools import setup, find_packages
setup(
    name="pantera-sample",
    version="0.2",
    author="Test",
    author_email="test@pantera.local",
    description="A sample Python package for testing",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.6",
)
